^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package xv_11_laser_driver
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.0 (2017-03-22)
------------------
* update default firmware_version to 2
* Contributors: Rohan Agrawal

0.2.2 (2014-09-15)
------------------
* added install rule for include files
* Contributors: Rohan Agrawal

0.2.1 (2014-09-14)
------------------
* merged Steve Dillo's include file
* Merge pull request `#1 <https://github.com/rohbotics/xv_11_laser_driver/issues/1>`_ from rohbotics/master
  Merge master and hydro-devel
* Contributors: Rohan Agrawal

0.2.0 (2014-02-22)
------------------
* Pulled in Steve 'dillo Okay's RPMs topic
* Contributors: Rohan Agrawal

0.1.2 (2013-11-23)
------------------
* initial commit
* Contributors: Rohan Agrawal
