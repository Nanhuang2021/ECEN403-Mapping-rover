
# Ubiquity Robotics Demos

This repository contains the following demos:

* [dnn_rotate](dnn_ratate) 
* [Fiducial Follow](fiducial_follow) 
* [move_demo](move_demo) 
* [Partybot](partybot) (work in progress)
* [Docking](docking)

