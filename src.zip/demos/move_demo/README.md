
# move_demo

This package provides a script that can be used to move a robot
by sending goals to [move_basic](http://wiki.ros.org/move_basic).

```
rosrun move_demo move.py rotate 90
rosrun move_demo move.py forward 1.0
```
