from ._StringTrigger import *
